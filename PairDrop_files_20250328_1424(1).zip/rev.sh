read num
reverse = $(echo "num"|rev)
if 
