echo "Enter a set of numbers separated by spaces : "

